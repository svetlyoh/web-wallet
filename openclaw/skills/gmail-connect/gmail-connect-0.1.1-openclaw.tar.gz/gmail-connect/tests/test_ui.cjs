// UI behavior smoke test using the actual script and a minimal DOM adapter.
// This does not replace visual validation in a real browser.
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');const assert=require('node:assert/strict');
class Element{constructor(){this.textContent='';this.value='';this.hidden=false;this.checked=false;this.children=[];this.events={};}addEventListener(n,f){this.events[n]=f;}replaceChildren(...c){this.children=c;}append(...c){this.children.push(...c);}}
const elements=new Map();const el=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
const calls=[];let popup;let confirm=false;
const responses={status:{connected:true,email:'test@example.com',clientImported:true,project:'sample-gmail',sending:true,service:{active:false}},search:{messages:[{id:'abc',subject:'<script>hostile()</script>',from:'sender@example.com',date:'today'}]},read:{text:'Email text'},drafts:[{id:'draft1',to:'friend@example.com',account:'test@example.com',subject:'Draft',body:'Exact body',status:'pending'}],connect:{url:'https://accounts.google.com/o/oauth2/v2/auth?test=1'},send:{sent:true}};
const context={document:{getElementById:el,createElement:()=>new Element()},location:{hash:'#private-capability'},sessionStorage:{setItem(k,v){this[k]=v;},getItem(k){return this[k];}},history:{replaceState(){}},window:{open(){popup={opener:'old'};return popup;},confirm(){return confirm;}},fetch:async(url,opts)=>{calls.push({url,opts});const data=responses[url.slice('/api/'.length)]||{};return{ok:true,json:async()=>data};},Date,Error,JSON,encodeURIComponent};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/ui/app.js'),'utf8'),context);
const flush=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{await flush();assert.equal(el('account').textContent,'test@example.com');assert.equal(el('sending').checked,true);assert.match(el('api-link').href,/project=sample-gmail/);
 el('query').value='in:inbox';await el('search').events.click();const title=el('messages').children[0].children[0];assert.equal(title.textContent,'<script>hostile()</script>');await title.onclick();assert.equal(el('message-body').textContent,'Email text');
 await el('drafts-button').events.click();const send=el('drafts').children[0].children[3];await send.onclick();assert(!calls.some(c=>c.url==='/api/send'));confirm=true;await send.onclick();assert.equal(calls.filter(c=>c.url==='/api/send').length,1);
 await el('authorize').events.click();assert.match(popup.location,/^https:\/\/accounts.google.com/);assert.equal(popup.opener,null);assert(calls.every(c=>c.opts.headers.Authorization==='Bearer private-capability'));assert.equal(el('authorize').disabled,false);
 console.log('UI smoke passed: status, project links, text-only mail rendering, read, exact-send confirmation, OAuth navigation, capability headers.');})().catch(e=>{console.error(e);process.exit(1);});
