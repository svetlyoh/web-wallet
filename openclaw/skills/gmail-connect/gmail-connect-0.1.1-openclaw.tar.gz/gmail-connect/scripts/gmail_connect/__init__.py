"""Gmail Connect local adapter."""
